from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.shortcuts import get_object_or_404, redirect, render

from .models import Reclamo


# ============================================================
# CLASE 1 — READ
# ============================================================

@login_required
def lista_reclamos(request):
    """
    Lista únicamente los reclamos del usuario autenticado (request.user).

    Pasos esperados:
    1. Filtrar Reclamo.objects con usuario=request.user
    2. Renderizar 'reclamos/lista.html' pasando esos reclamos en el contexto

    Pista: no muestres TODOS los reclamos, solo los del usuario logueado.
    Eso se hace con .filter(usuario=request.user)
    """
    pass


@login_required
def detalle_reclamo(request, id):
    """
    Muestra el detalle de un reclamo específico.

    Pasos esperados:
    1. Buscar el reclamo por id usando get_object_or_404
    2. Verificar que el reclamo pertenezca al usuario autenticado
       (si no es el dueño, no debería poder verlo)
    3. Renderizar 'reclamos/detalle.html' con el reclamo en el contexto

    Pista: get_object_or_404(Reclamo, id=id, usuario=request.user)
    ya filtra y da 404 si no es del usuario, en una sola línea.
    """
    pass


# ============================================================
# CLASE 2 — CREATE / UPDATE
# ============================================================

@login_required
def crear_reclamo(request):
    """
    Crea un nuevo reclamo o sugerencia para el usuario autenticado.

    Pasos esperados:
    1. Si request.method == 'POST':
       - Leer 'tipo', 'titulo', 'descripcion' desde request.POST
       - Crear el Reclamo con Reclamo.objects.create(...)
         asignando usuario=request.user (NO pedirlo en el formulario)
       - Redirigir a la lista de reclamos
    2. Si es GET, renderizar 'reclamos/form.html' (formulario vacío)

    Pista: el campo 'usuario' nunca debe venir del formulario.
    Siempre se asigna desde request.user por seguridad.
    """
    pass


@login_required
def editar_reclamo(request, id):
    """
    Edita un reclamo existente. Solo el usuario que lo creó puede editarlo.

    Pasos esperados:
    1. Buscar el reclamo con get_object_or_404(Reclamo, id=id, usuario=request.user)
    2. Si request.method == 'POST':
       - Actualizar tipo, titulo y descripcion desde request.POST
       - Guardar con .save()
       - Redirigir al detalle o a la lista
    3. Si es GET, renderizar 'reclamos/form.html' con el reclamo
       precargado en el contexto (para mostrar los valores actuales)

    Pista: no se puede editar 'estado' aquí — eso es exclusivo
    del bibliotecario en el panel (Clase 3).
    """
    pass


# ============================================================
# CLASE 3 — DELETE + PANEL BIBLIOTECARIO
# ============================================================

@login_required
def eliminar_reclamo(request, id):
    """
    Elimina un reclamo, con pantalla de confirmación previa.

    Pasos esperados:
    1. Buscar el reclamo con get_object_or_404(Reclamo, id=id, usuario=request.user)
    2. Si request.method == 'POST':
       - Eliminar con .delete()
       - Redirigir a la lista de reclamos
    3. Si es GET, renderizar 'reclamos/confirmar_eliminar.html'
       mostrando los datos del reclamo a eliminar (sin borrar todavía)

    Pista: nunca elimines directamente en un GET. Siempre pedir
    confirmación con un formulario POST.
    """
    pass


@login_required
@permission_required('reclamos.change_reclamo', raise_exception=True)
def panel_reclamos(request):
    """
    Panel para el bibliotecario: ve TODOS los reclamos de TODOS los
    usuarios y puede cambiar su estado (pendiente / en_revision / resuelto).

    Pasos esperados:
    1. Obtener todos los reclamos con Reclamo.objects.all()
       (acá SÍ se ven todos, no solo los del usuario actual)
    2. Si request.method == 'POST':
       - Leer el id del reclamo y el nuevo estado desde request.POST
       - Buscar ese reclamo, actualizar su 'estado', guardar
       - Redirigir de nuevo al panel
    3. Renderizar 'reclamos/panel.html' con todos los reclamos

    Pista: este es el único rol que puede cambiar 'estado'. Por eso
    lleva @permission_required además de @login_required.
    """
    pass
